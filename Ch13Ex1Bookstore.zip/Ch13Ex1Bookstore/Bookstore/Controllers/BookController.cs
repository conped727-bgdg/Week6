﻿using Microsoft.AspNetCore.Mvc;
using Bookstore.Models;
using System.Xml.Linq;

namespace Bookstore.Controllers
{
    public class BookController : Controller
    {
        private readonly IWebHostEnvironment _env;
        private Repository<Book> data { get; set; }

        public BookController(BookstoreContext ctx, IWebHostEnvironment env)
        {
            data = new Repository<Book>(ctx);
            _env = env;
        }

        public RedirectToActionResult Index() => RedirectToAction("List");
        
        [HttpPost]
        public RedirectToActionResult PageSize(BookGridData currentRoute)
        {
            currentRoute.PageNumber = 1;
            return RedirectToAction("List", currentRoute.ToDictionary());
        }

        public ViewResult List(BookGridData values)
        {
            // create options for querying books
            var options = new QueryOptions<Book> { 
                Includes = "Authors, Genre",
                OrderByDirection = values.SortDirection,
                PageNumber = values.PageNumber,
                PageSize = values.PageSize
            };
            if (values.IsSortByGenre) 
                options.OrderBy = b => b.GenreId;
            else if (values.IsSortByPrice) 
                options.OrderBy = b => b.Price;
            else 
                options.OrderBy = b => b.Title;

            // create view model
            var vm = new BookListViewModel { 
                Books = data.List(options),
                CurrentRoute = values,
                TotalPages = values.GetTotalPages(data.Count)
            };

            return View(vm);
        }

        public ViewResult Details(int id)
        {
            var book = data.Get(new QueryOptions<Book> {
                Where = b => b.BookId == id,
                Includes = "Authors, Genre"
            }) ?? new Book();
            return View(book);
        }

        public IActionResult ExportToXml()
        {
            var options = new QueryOptions<Book>
            {
                Includes = "Authors, Genre"
            };

            var books = data.List(options);

            var doc = new XDocument(
                new XElement("Books",
                    books.Select(book =>
                        new XElement("Book",
                            new XElement("ID", book.BookId),
                            new XElement("Title", book.Title),
                            new XElement("Authors",
                                string.Join(", ", book.Authors.Select(a => a.FullName))
                            ),
                            new XElement("Price", book.Price),
                            new XElement("Genre", book.Genre?.Name ?? "")
                        )
                    )
                )
            );

            string path = Path.Combine(_env.WebRootPath, "data", "books.xml");
            doc.Save(path);

            TempData["message"] = "Books exported to XML successfully.";
            return RedirectToAction("List");
        }
    }
}